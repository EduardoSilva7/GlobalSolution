# ClimaResponde

## Instruções

### Build e Run

```bash
docker-compose up --build
```

### Endpoints

CRUD completo disponível em `/api/items`

## Tecnologias

- Java 17
- Spring Boot
- PostgreSQL
- Docker & Docker Compose